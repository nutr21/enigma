var winWidth,
    winHeight;


function set_background() {
    $('.set-bg').each(function () {
        if (typeof $(this).attr('data-mob-img') === 'undefined') {
            $(this).css({
                'background': 'url(' + $(this).attr('data-img') + ')',
                'background-size': 'cover'
            });
        } else {
            if (winWidth > mobile_breakbpoint) {
                if (typeof $(this).attr('data-img') != 'undefined') {
                    $(this).css({
                        'background': 'url(' + $(this).attr('data-img') + ')',
                        'background-size': 'cover'
                    });
                }
            } else {
                $(this).css({
                    'background': 'url(' + $(this).attr('data-mob-img') + ')',
                    'background-size': 'cover'
                });
            }
        }
    });
}






function custom_dropdown() {
    $('select').niceSelect();
    //   FastClick.attach(document.body);

}

function custom_timer() {

    function makeTimer() {

        //		var endTime = new Date("29 April 2018 9:56:00 GMT+01:00");	
        var endTime = new Date("15 May 2020 9:56:00 GMT+01:00");
        endTime = (Date.parse(endTime) / 1000);

        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        var days = Math.floor(timeLeft / 86400);
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }

        console.log(days);
        $("#days").html(Math.abs(days) + "<span>Days</span>");
        $("#hours").html(hours + "<span>Hours</span>");
        $("#minutes").html(minutes + "<span>Minutes</span>");
        $("#seconds").html(seconds + "<span>Seconds</span>");

    }

    //setInterval(function () { makeTimer(); }, 1000);

    function Timer(duration, display) {
        var timer = duration, hours, minutes, seconds;
        setInterval(function () {
            hours = parseInt((timer / 3600) % 24, 10)
            minutes = parseInt((timer / 60) % 60, 10)
            seconds = parseInt(timer % 60, 10);

            hours = hours < 10 ? "0" + hours : hours;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            //display.text(hours +":"+minutes + ":" + seconds);
            $("#days").html(00 + "<span>Days</span>");
            $("#hours").html(hours + "<span>Hours</span>");
            $("#minutes").html(minutes + "<span>Minutes</span>");
            $("#seconds").html(seconds + "<span>Seconds</span>");

            --timer;
        }, 1000);
    }

    jQuery(function ($) {
        var twentyFourHours = 24 * 60 * 60;
        //var display = $('#remainingTime');
        Timer(twentyFourHours);
    });
}

function animate() {
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: false, // default
        live: true // default
    })
    wow.init();

}



function scroll_last() {
    $(".cm-scroll-down").click(function () {
        $('html,body').animate({
            scrollTop: $(".pg-bottom-contact").offset().top
        },
            '10000');
    });
}





function get_height_width() {
    winWidth = $(window).width(),
        winHeight = $(window).height();
}

function set_height_width() {
    if ($('body').height() < winHeight) {
        $('.wh').outerHeight(winHeight);
    }
    $('.wh-min').css('min-height', winHeight);
    $('.ww').outerWidth(winWidth);
}



$(window).load(function () {
    custom_dropdown();
});















function stickyMenu() {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 60) {
            $('.bs-header').addClass("sticky");
        } else {
            $('.bs-header').removeClass("sticky");
        }
    });
}


function menuActive() {
    var m = $('.bs-header').attr('data-nav').toLowerCase();
    $('.main-nav li a').each(function (index) {
        if ($(this).html().toLowerCase() == m) {
            $(this).addClass('active');
        } else {
            $(this).removeClass('active');
        }
    });
}
var current_step = 1;

function set_bg(bgUrl) {
    $('.cm-stepperimage').css({
        'background': 'url(' + bgUrl + ')',
        'background-size': 'cover',
        'transition': 'all linear 0.5s',
        'background-position': 'center center'
    });


}

function stepper() {
    set_bg($('.stepper-steps .step:nth-of-type(1)').attr('data-img'));
    $('.stepper-radio,.stpper-continue').click(function () {
        var next_element = $('.stepper-steps .step:nth-of-type(' + (current_step + 1) + ')');
        if (next_element.length != 0) {
            setTimeout(function () {
                next_element.prev().hide();
                next_element.show();
            }, 500);
            $('.cm-progressbar li:nth-of-type(' + (current_step + 1) + ')').addClass('active');
            var bgUrl = next_element.attr('data-img');
            set_bg(bgUrl);

            current_step++;
        } else {
            $('.stepper-parent').hide();
            $('.stepper-success').show();
            set_bg($('.success-box').attr('data-img'));
        }
    });
}

function validation() {
    $.validator.addMethod('minlength', function (value, element, param) {
        let filter = /^\d{10}$/;
        return filter.test(value);
    });
    $.validator.addMethod("lettersonly", function (value, element) {
        return this.optional(element) || /^[a-z," "]+$/i.test(value);
    }, "Letters and spaces only please");
    $("#order-now-form").validate({
        rules: {
            cust_name: {
                required: true,
                lettersonly: true,
            },
            cust_phone: {
                required: true,
                number: true,
                minlength: 10,
            },
            city: {
                required: true,
            },
        },
        messages: {
            cust_phone: {
                minlength: "please enter alteast 10 digit mobile number.",
            }
        },
        submitHandler: function (form, event) {
            event.preventDefault();
            let formData = $("#order-now-form").serializeArray();
            let pageName = window.location.pathname.split('/').pop();
            formData.push({name: 'type',value: 'order'});
            formData.push({name: 'page',value: pageName});
            $("button[type='submit'], input[type='submit']").attr('disabled', true);
            $.ajax({
                type: 'POST',
                url: BASE_URL + 'order-now-post.php',
                data: formData,
                dataType: 'JSON',
                success: function (data) {
                    console.log(data);
                    if (data.status === 200) {
                        $(".cm-success-msg").show();
                    } else {
                        $(".cm-fail-msg").show();
                    }
                },
                complete:function(){
                    $("button[type='submit'], input[type='submit']").attr('disabled', false);
                }
            });
        }
    });
}

function navigate_to_form() {
    $(document).on('click', '.post-landing .bs-btn.goto-form', function (event) {
        event.preventDefault();

        $('html, body').animate({
            scrollTop: $(".pg-bottom-contact").offset().top
        }, 800);
    });
}



function set_date() {
    var d = new Date();
    $('.today').text(d.getDate() + "." + (d.getMonth() + 1) + "." + d.getFullYear());
}


$(function () {
    get_height_width();
    set_height_width();
    set_background();
    custom_timer();
    stepper();
    scroll_last();
    validation();
    navigate_to_form();
    set_date();
});